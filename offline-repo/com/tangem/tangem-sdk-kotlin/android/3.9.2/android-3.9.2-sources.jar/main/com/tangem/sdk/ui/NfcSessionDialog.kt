package com.tangem.sdk.ui

import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import androidx.annotation.UiThread
import com.google.android.material.bottomsheet.BottomSheetBehavior
import com.tangem.Log
import com.tangem.ViewDelegateMessage
import com.tangem.common.CompletionResult
import com.tangem.common.Timer
import com.tangem.common.core.*
import com.tangem.sdk.R
import com.tangem.sdk.SessionViewDelegateState
import com.tangem.sdk.extensions.SecurityModeController
import com.tangem.sdk.extensions.hide
import com.tangem.sdk.extensions.show
import com.tangem.sdk.nfc.CompositeNfcLocationProvider
import com.tangem.sdk.nfc.NfcManager
import com.tangem.sdk.postUI
import com.tangem.sdk.ui.widget.*
import com.tangem.sdk.ui.widget.howTo.HowToTapWidget
import com.tangem.sdk.ui.widget.progressBar.ProgressbarStateWidget
import com.tangem.sdk.url.DefaultUrlOpener
import com.tangem.sdk.url.UrlOpener
import kotlinx.coroutines.Dispatchers

@Suppress("LargeClass")
class NfcSessionDialog(
    context: Context,
    private val nfcManager: NfcManager,
    private val compositeProvider: CompositeNfcLocationProvider,
    private val iconScanRes: Int? = null,
) : BaseSdkDialog(context) {

    private lateinit var taskContainer: ViewGroup
    private lateinit var howToContainer: ViewGroup
    private lateinit var welcomeBackContainer: ViewGroup

    private lateinit var headerWidget: HeaderWidget
    private lateinit var touchCardWidget: TouchCardWidget
    private lateinit var progressStateWidget: ProgressbarStateWidget
    private lateinit var pinCodeRequestWidget: PinCodeRequestWidget
    private lateinit var pinCodeSetChangeWidget: PinCodeModificationWidget
    private lateinit var messageWidget: MessageWidget
    private lateinit var howToTapWidget: HowToTapWidget
    private lateinit var welcomeBackWidget: AlreadyActivatedWidget

    private var currentState: SessionViewDelegateState? = null
    private val urlOpener: UrlOpener = DefaultUrlOpener(context)

    @Deprecated("Used to fix lack of security delay on cards with firmware version below 1.21")
    private var emulateSecurityDelayTimer: Timer? = null

    init {
        val dialogView = LayoutInflater.from(context).inflate(R.layout.bottom_sheet_layout, null)
        setContentView(dialogView)
    }

    override fun setContentView(view: View) {
        super.setContentView(view)

        val nfcLocationData = compositeProvider.getLocationData()

        taskContainer = view.findViewById(R.id.taskContainer)
        howToContainer = view.findViewById(R.id.howToContainer)
        welcomeBackContainer = view.findViewById(R.id.welcomeBackContainer)

        headerWidget = HeaderWidget(view.findViewById(R.id.llHeader))
        touchCardWidget = TouchCardWidget(view.findViewById(R.id.flImageContainer), nfcLocationData)
        touchCardWidget.setIconScanRes(iconScanRes)
        progressStateWidget = ProgressbarStateWidget(view.findViewById(R.id.clProgress))
        pinCodeRequestWidget = PinCodeRequestWidget(view.findViewById(R.id.csPinCode))
        pinCodeSetChangeWidget = PinCodeModificationWidget(
            view.findViewById(R.id.llChangePin),
            PinCodeModificationWidget.Mode.SET,
        )
        messageWidget = MessageWidget(view.findViewById(R.id.llMessage))
        howToTapWidget = HowToTapWidget(howToContainer, nfcManager, compositeProvider)
        val layoutInflater = LayoutInflater.from(view.context)
        val welcomeBackView = layoutInflater.inflate(R.layout.already_activated_widget_layout, null)
        welcomeBackContainer.removeAllViews()
        welcomeBackContainer.addView(welcomeBackView)
        welcomeBackWidget = AlreadyActivatedWidget(welcomeBackView)

        stateWidgets.add(headerWidget)
        stateWidgets.add(touchCardWidget)
        stateWidgets.add(progressStateWidget)
        stateWidgets.add(pinCodeRequestWidget)
        stateWidgets.add(pinCodeSetChangeWidget)
        stateWidgets.add(messageWidget)
        stateWidgets.add(howToTapWidget)
        stateWidgets.add(welcomeBackWidget)

        headerWidget.onHowTo = { show(SessionViewDelegateState.HowToTap) {} }

        behavior.state = BottomSheetBehavior.STATE_COLLAPSED
    }

    override fun onStop() {
        super.onStop()
        dismiss()
        SecurityModeController.setSecurityMode(dialog = this, value = false)
    }

    @UiThread
    fun showHowTo(enable: Boolean) {
        headerWidget.howToIsEnabled = enable
    }

    @UiThread
    fun setInitialMessage(message: ViewDelegateMessage?) {
        messageWidget.setInitialMessage(message)
    }

    @UiThread
    fun setMessage(message: ViewDelegateMessage?) {
        messageWidget.setMessage(message)
    }

    fun setScanImage(scanImage: ScanTagImage) {
        touchCardWidget.setScanImage(scanImage)
    }

    fun show(state: SessionViewDelegateState, onDialogShowed: () -> Unit) {
        postUI {
            if (ownerActivity?.isFinishing == true) return@postUI
            if (!this.isShowing) {
                show()
            }

            setSecurityModelIfPinCode(state)

            handleSessionViewDelegateState(state, onDialogShowed)

            currentState = state
        }
    }

    private fun setSecurityModelIfPinCode(state: SessionViewDelegateState) {
        if (state is SessionViewDelegateState.PinRequested || state is SessionViewDelegateState.PinChangeRequested) {
            SecurityModeController.setSecurityMode(dialog = this, value = true)
        } else if (SecurityModeController.isEnabled) { // if current state isn't pin code and Security mode is enabled
            SecurityModeController.setSecurityMode(dialog = this, value = false)
        }
    }

    private fun handleSessionViewDelegateState(state: SessionViewDelegateState, onDialogShowed: () -> Unit) {
        when (state) {
            is SessionViewDelegateState.Ready -> onReady(state)
            is SessionViewDelegateState.Success -> onSuccess(state, onDialogShowed)
            is SessionViewDelegateState.Error -> onError(state)
            is SessionViewDelegateState.SecurityDelay -> onSecurityDelay(state)
            is SessionViewDelegateState.Delay -> onDelay(state)
            is SessionViewDelegateState.PinRequested -> onPinRequested(state)
            is SessionViewDelegateState.PinChangeRequested -> onPinChangeRequested(state)
            is SessionViewDelegateState.WrongCard -> onWrongCard(state)
            is SessionViewDelegateState.TagConnected -> onTagConnected(state)
            is SessionViewDelegateState.TagLost -> onTagLost(state)
            is SessionViewDelegateState.HowToTap -> howToTap(state)
            is SessionViewDelegateState.AlreadyActivated -> alreadyActivated(state, state.callback)
            is SessionViewDelegateState.None,
            is SessionViewDelegateState.ResetCodes,
            -> Unit
        }
    }

    private fun onReady(state: SessionViewDelegateState.Ready) {
        setStateAndShow(state, headerWidget, touchCardWidget, messageWidget)
    }

    private fun onSuccess(state: SessionViewDelegateState.Success, onDialogShowed: () -> Unit) {
        setStateAndShow(state, headerWidget, progressStateWidget, messageWidget)
        performHapticFeedback()
        postUI(msTime = 100) {
            dismissInternal()
            onDialogShowed()
        }
    }

    private fun onError(state: SessionViewDelegateState.Error) {
        setStateAndShow(state, headerWidget, progressStateWidget, messageWidget)
        performHapticFeedback()
    }

    private fun onSecurityDelay(state: SessionViewDelegateState.SecurityDelay) {
        if (state.ms == SessionEnvironment.missingSecurityDelayCode) {
            activateTrickySecurityDelay(state.totalDurationSeconds.toLong())
            return
        }
        setStateAndShow(state, headerWidget, progressStateWidget, messageWidget)
        performHapticFeedback()
    }

    private fun onDelay(state: SessionViewDelegateState.Delay) {
        setStateAndShow(state, headerWidget, progressStateWidget, messageWidget)
        performHapticFeedback()
    }

    private fun onPinRequested(state: SessionViewDelegateState.PinRequested) {
        val delayMs = if (currentState is SessionViewDelegateState.SecurityDelay) SECURITY_DELAY_MS else 0L

        postUI(delayMs) {
            enableBottomSheetAnimation()
            headerWidget.onClose = {
                dismissWithAnimation = false
                cancel()
            }
            behavior.state = BottomSheetBehavior.STATE_EXPANDED

            // pincode entering failed if an user dismiss the dialog from any moment
            pinCodeRequestWidget.onBottomSheetDismiss = {
                state.callback(CompletionResult.Failure(TangemSdkError.UserCancelled()))
            }

            pinCodeRequestWidget.onContinue = {
                enableBottomSheetAnimation()
                pinCodeRequestWidget.onContinue = null
                setStateAndShow(getEmptyOnReadyEvent(), headerWidget, touchCardWidget, messageWidget)
                postUI(msTime = 200) { state.callback(it) }
            }

            setStateAndShow(state, headerWidget, pinCodeRequestWidget)
            performHapticFeedback()
        }
    }

    private fun onPinChangeRequested(state: SessionViewDelegateState.PinChangeRequested) {
        enableBottomSheetAnimation()
        behavior.state = BottomSheetBehavior.STATE_EXPANDED

        headerWidget.howToIsEnabled = false
        headerWidget.onClose = {
            dismissWithAnimation = false
            cancel()
        }
        // userCode changes failed if an user dismiss the dialog from any moment
        pinCodeSetChangeWidget.onBottomSheetDismiss = {
            state.callback(CompletionResult.Failure(TangemSdkError.UserCancelled()))
        }
        pinCodeSetChangeWidget.onSave = {
            enableBottomSheetAnimation()
            // disable sending the error if dialog closed after accepting an userCode
            pinCodeSetChangeWidget.onBottomSheetDismiss = null
            pinCodeSetChangeWidget.onSave = null

            setStateAndShow(getEmptyOnReadyEvent(), headerWidget, touchCardWidget, messageWidget)
            postUI(msTime = 200) { state.callback(CompletionResult.Success(it.trim())) }
        }

        setStateAndShow(state, headerWidget, pinCodeSetChangeWidget)
        performHapticFeedback()
    }

    private fun onTagLost(state: SessionViewDelegateState) {
        when (currentState) {
            is SessionViewDelegateState.Success,
            is SessionViewDelegateState.PinRequested,
            is SessionViewDelegateState.PinChangeRequested,
            is SessionViewDelegateState.Error,
            -> {
                return
            }

            else -> {
                setStateAndShow(state, headerWidget, touchCardWidget, messageWidget)
            }
        }
    }

    private fun onTagConnected(state: SessionViewDelegateState) {
        setStateAndShow(state, headerWidget, progressStateWidget, messageWidget)
    }

    private fun onWrongCard(state: SessionViewDelegateState.WrongCard) {
        Log.view { "showing wrong card. Type: ${state.wrongValueType}" }
        if (currentState !is SessionViewDelegateState.WrongCard) {
            performHapticFeedback()
            setStateAndShow(state, headerWidget, progressStateWidget, messageWidget)
            postUI(msTime = 4000) {
                currentState = getEmptyOnReadyEvent()
                setStateAndShow(currentState!!, headerWidget, touchCardWidget, messageWidget)
            }
        }
    }

    private fun howToTap(state: SessionViewDelegateState) {
        Log.view { "showing how to tap" }
        enableBottomSheetAnimation()
        behavior.state = BottomSheetBehavior.STATE_EXPANDED
        taskContainer.hide()
        findDesignBottomSheetView()?.let { it.layoutParams.height = ViewGroup.LayoutParams.MATCH_PARENT }
        howToContainer.show()

        howToTapWidget.previousState = currentState
        howToTapWidget.onCloseListener = {
            howToTapWidget.onCloseListener = null
            enableBottomSheetAnimation()
            howToContainer.hide()
            findDesignBottomSheetView()?.let { it.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT }
            taskContainer.show()

            howToTapWidget.previousState?.let {
                howToTapWidget.setState(it)
                show(it) {}
            }
            howToTapWidget.previousState = null
        }
        setStateAndShow(state, howToTapWidget)
    }

    private fun alreadyActivated(state: SessionViewDelegateState, callback: CompletionCallback<Unit>) {
        Log.view { "showing alreadyActivated" }
        enableBottomSheetAnimation()
        behavior.state = BottomSheetBehavior.STATE_EXPANDED
        taskContainer.hide()
        findDesignBottomSheetView()?.let { it.layoutParams.height = ViewGroup.LayoutParams.MATCH_PARENT }
        howToContainer.hide()
        welcomeBackContainer.show()

        welcomeBackWidget.onConfirm = {
            welcomeBackWidget.onConfirm = null
            welcomeBackContainer.hide()
            taskContainer.show()
            findDesignBottomSheetView()?.let { it.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT }
            callback.invoke(CompletionResult.Success(Unit))
        }

        welcomeBackWidget.onJustBoughtClick = {
            urlOpener.openUrlExternalBrowser(getPreactivatedWalletsUrl(context))
            welcomeBackContainer.hide()
            taskContainer.show()
            findDesignBottomSheetView()?.let { it.layoutParams.height = ViewGroup.LayoutParams.WRAP_CONTENT }
            callback.invoke(CompletionResult.Failure(TangemSdkError.UserCancelled()))
        }
        setStateAndShow(state, welcomeBackWidget)
    }

    override fun setStateAndShow(
        state: SessionViewDelegateState,
        vararg views: StateWidget<SessionViewDelegateState>,
    ) {
        handleStateForTrickySecurityDelay(state)
        super.setStateAndShow(state, *views)
    }

    @Deprecated("Used to fix lack of security delay on cards with firmware version below 1.21")
    private fun activateTrickySecurityDelay(totalDuration: Long) {
        val timer = Timer(period = totalDuration, step = 100L, delayMs = 1000L, dispatcher = Dispatchers.IO)
        timer.onComplete = {
            postUI { onSecurityDelay(SessionViewDelegateState.SecurityDelay(0, 0, ProductType.ANY)) }
        }
        timer.onTick = {
            postUI {
                onSecurityDelay(
                    SessionViewDelegateState.SecurityDelay(
                        ms = (totalDuration - it).toInt(),
                        totalDurationSeconds = 0,
                        productType = ProductType.ANY,
                    ),
                )
            }
        }
        timer.start()
        emulateSecurityDelayTimer = timer
    }

    @Deprecated("Used to fix lack of security delay on cards with firmware version below 1.21")
    private fun handleStateForTrickySecurityDelay(state: SessionViewDelegateState) {
        if (emulateSecurityDelayTimer == null) return

        when (state) {
            SessionViewDelegateState.TagConnected -> {
                emulateSecurityDelayTimer?.period?.let { activateTrickySecurityDelay(it) }
            }

            is SessionViewDelegateState.TagLost -> {
                emulateSecurityDelayTimer?.cancel()
            }

            is SessionViewDelegateState.SecurityDelay -> {
                // do nothing for saving the securityDelay timer logic
            }

            else -> {
                emulateSecurityDelayTimer?.cancel()
                emulateSecurityDelayTimer = null
            }
        }
    }

    private fun getEmptyOnReadyEvent(): SessionViewDelegateState {
        return SessionViewDelegateState.Ready(headerWidget.cardId, ProductType.ANY)
    }

    private fun getPreactivatedWalletsUrl(context: Context): String {
        val defaultLanguage = "en"
        val supportedLanguages = setOf("en", "es", "de", "ja", "ru")
        val deviceLocales = context.resources.configuration.locales
        val currentLanguage = if (deviceLocales.isEmpty) {
            defaultLanguage
        } else {
            deviceLocales[0].language
        }
        val actualLanguage = if (currentLanguage in supportedLanguages) {
            currentLanguage
        } else {
            defaultLanguage
        }
        val deviceLang = currentLanguage.uppercase()
        return "https://tangem.com/embed/$actualLanguage/blog/post/preactivated-wallets/" +
            "?utm_source=tangem-app&utm_medium=app" +
            "&utm_campaign=articles-sdk-$actualLanguage&utm_content=devicelang-$deviceLang"
    }

    private companion object {
        const val SECURITY_DELAY_MS = 950L
    }
}